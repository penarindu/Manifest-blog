export async function handler(event) {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: "Method Not Allowed"
    };
  }

  const body = JSON.parse(event.body);

  // Ganti dengan Measurement ID dan API Secret kamu
  const measurementId = "G-HT3918FWDW";
  const apiSecret = "QgY64L4yTlihQ1nzlBS9iA";

  const response = await fetch(`https://www.google-analytics.com/mp/collect?measurement_id=${measurementId}&api_secret=${apiSecret}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });

  return {
    statusCode: response.status,
    body: await response.text()
  };
}